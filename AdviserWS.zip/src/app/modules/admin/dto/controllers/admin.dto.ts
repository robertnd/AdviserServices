export type AdminDto = {
    user_id: string
    password: string
    email: string
    mobile_no: string
}