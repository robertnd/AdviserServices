export type AdviserQuery = {
    key: 'kra_pin' | 'mobile_no' | 'id_number'
    value: string,
    mobile_no?: string
  }