export type FileDataDto = {
    user_id: string
    file_desc: string
    file_data: string
}