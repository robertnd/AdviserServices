export type FileDataDto = {
    applicant_id: number
    file_desc: string
    file_data: string
}