export type StaffDto = {
    first_name: string
    last_name: string
    full_names: string
    gender: string
    id_number: string
    id_type: string
    date_of_birth: string
    mobile_no: string
    primary_email: string
    partner_number: string
} 