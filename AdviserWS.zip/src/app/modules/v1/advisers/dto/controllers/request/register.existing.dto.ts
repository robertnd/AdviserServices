import { DataPlatformAdviser } from "../../data_platform/data-platform.adviser.dto"
import { UserDto } from "../../user.dto"

export type RegistrationDto = {
    user_id: string
    password: string
    otp: string
} & ( MigratedAdviser | Applicant | StaffUser )

type MigratedAdviser = {
    reg_type: 'migrated'
    dpAdviser: DataPlatformAdviser
}

type Applicant = {
    reg_type: 'applicant'
    applicant: Applicant
}

type StaffUser = {
    reg_type: 'staff'
    adviser_user_id: string
    user: UserDto
}