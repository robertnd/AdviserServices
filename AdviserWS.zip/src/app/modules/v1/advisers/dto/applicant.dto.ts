export type ApplicantDto = {
    first_name: string
    last_name: string
    full_names: string
    gender: string
    date_of_birth: string
    id_type: string
    id_number: string
    kra_pin: string
    mobile_no: string
    primary_email: string
    primary_address: string
    city: string
    country: string
}
