export type Applicant = {
    id: string
    firstName: string
    otherNames: string
    surname: string
    gender: string
    dateOfBirth: string
    docNumber: string
    idDocument: string
    PIN: string
    mobile: string
    homeNumber: string
    email: string
    postalAddress: string
    townCity: string
    physicalAddress: string
    nationality: string
    countryOfResidence: string
    partnerNumber: string
}