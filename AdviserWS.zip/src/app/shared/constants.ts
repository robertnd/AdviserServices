export enum CredentialType {
    'root', 'admin', 'adviser-admin', 'adviser-user', 'adviser-applicant'
}

export enum RBAC {
    'Registered', 'TBD'
}

export enum IntermediaryType {
    'Applicant', 'Migrated', ''
}

export enum LegalEntityType {
    'person', 'non-person'
}

export enum AdviserStatus {
    'Pending-Approval', 'Active'
}


/*
credential_type = [ root, admin, adviser-admin, adviser-user, adviser-applicant ]
rbac = [ Registered, ? ]
intermediary_type = [ Applicant ]
legal_entity_type = [ person, non-person ]
status = [ Pending Approval, Active, ? ]

*/