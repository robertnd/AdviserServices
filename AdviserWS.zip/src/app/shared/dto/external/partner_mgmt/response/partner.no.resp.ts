export type PartnerNumberResponse = {
    Code: number
    Status: string
    partnerNumber: string
}