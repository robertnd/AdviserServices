export type PartnerNumberRequest = {
    firstname: string
    middlename: string
    surname: string
    emailaddress1: string
    dateofbirth: string
    pin_ke: string
}


